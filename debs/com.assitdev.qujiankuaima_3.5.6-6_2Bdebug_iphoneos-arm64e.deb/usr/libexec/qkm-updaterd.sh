#!/bin/sh
# 取件快码 Assit — root 自动更新守护进程（Author: AssitDev）
#
# 三条通道，全部以 root 执行，用户不用在手机上点任何东西：
#   ① 把 deb 推成 /var/mobile/Media/Downloads/qujiankuaima_update.deb → 自动 dpkg -i
#   ② 往 .../QujianKuaiMa/install.cmd 写一行 deb 路径 → 自动 dpkg -i
#   ③ 往 .../QujianKuaiMa/cmd.txt 写一段 shell → 以 root 执行，输出写 cmd.log
#      （第 ③ 条用来装 frida / 跑 uicache / 重启 sshd 这类一次性动作）

DIR=/var/mobile/Media/Downloads/QujianKuaiMa
STAGE=/var/mobile/Media/Downloads/qujiankuaima_update.deb
LOG=$DIR/install.txt
CMD=$DIR/cmd.txt
CMDLOG=$DIR/cmd.log

JB=""
[ -d /var/jb ] && JB="/var/jb"
DPKG=""
for d in "$JB/usr/bin/dpkg" /usr/bin/dpkg "$JB/bin/dpkg"; do
  [ -x "$d" ] && { DPKG="$d"; break; }
done

mkdir -p "$DIR" 2>/dev/null
chown mobile:mobile "$DIR" 2>/dev/null

while true; do
  # ---------- ③ root shell 通道 ----------
  if [ -f "$CMD" ]; then
    cp "$CMD" "$CMD.sh" 2>/dev/null
    rm -f "$CMD" 2>/dev/null
    if [ -f "$CMD.sh" ]; then
      {
        echo "=== qkm-cmd $(date) ==="
        /bin/sh "$CMD.sh" 2>&1
        echo "CMD_EXIT=$?"
      } >> "$CMDLOG" 2>&1
      rm -f "$CMD.sh" 2>/dev/null
      chown mobile:mobile "$CMDLOG" 2>/dev/null
      chmod 644 "$CMDLOG" 2>/dev/null
    fi
  fi

  # ---------- ①② deb 通道 ----------
  DEB=""
  if [ -f "$DIR/install.cmd" ]; then
    DEB=$(head -n1 "$DIR/install.cmd" 2>/dev/null | tr -d '\r\n ')
    rm -f "$DIR/install.cmd" 2>/dev/null
  elif [ -f "$STAGE" ]; then
    DEB="$STAGE"
  fi

  if [ -n "$DEB" ] && [ -f "$DEB" ] && [ -n "$DPKG" ]; then
    {
      echo "=== qkm-updater $(date) ==="
      echo "deb=$DEB"
      "$DPKG" -i "$DEB" 2>&1
      echo "DPKG_EXIT=$?"
    } >> "$LOG" 2>&1
    rm -f "$DEB" 2>/dev/null
    chown mobile:mobile "$LOG" 2>/dev/null
    chmod 644 "$LOG" 2>/dev/null
    sleep 1
    ( sleep 2; killall -9 SpringBoard ) >/dev/null 2>&1 &
  fi

  sleep 3
done
